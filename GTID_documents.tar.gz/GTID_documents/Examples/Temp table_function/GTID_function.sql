
Temporary table usage [creation + insertion + selection anything] either in function or in java page & function call from module / Java page.

#====================JAVA PAGE DEFINITION START====================================#
set autocommit=on;
DROP TEMPORARY TABLE IF EXISTS SCHEMA_NAME.TEMP_TABLE ;
CREATE TEMPORARY TABLE IF NOT EXISTS SCHEMA_NAME.TEMP_TABLE AS SELECT * FROM SCHEMA_NAME.BASE_TABLE ;
set autocommit=off;
/*WRITE ALL THE OTHER CODING STUFF*/  [including function call ; data insertion in temporary table ; DMLs on base tables]
commit ;
conn.close ; 
#====================JAVA PAGE DEFINITION START====================================#

#====================function DEFINITION START====================================#

/*All the other logic except temporary table creation / drop */

#====================function DEFINITION END====================================#



Note : Error Code: 1445. Not allowed to set autocommit from a stored function or trigger.
