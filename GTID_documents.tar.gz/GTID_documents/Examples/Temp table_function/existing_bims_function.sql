CREATE DEFINER=`njindiainvest`@`%` FUNCTION `GETCENTERHIERARCHY`(MECODE VARCHAR(15),EMPTYPE VARCHAR(15),REPTYPE VARCHAR(15)) RETURNS text CHARSET latin1
BEGIN
            DECLARE T_CENTERCODE VARCHAR(20);
            DECLARE V_CENTERCODE VARCHAR(20);
            DECLARE F_CENTERCODE VARCHAR(20);
            DECLARE T_MECODE VARCHAR(15);
            DECLARE DIST_DONE INT DEFAULT 0;
            DECLARE RES TEXT DEFAULT '-1';

            DECLARE CUR_CENTER CURSOR FOR SELECT CENTRECODE FROM ( SELECT DISTINCT                                                            
                     CASE WHEN R1.REGTYPE='R4' THEN R1.REGCODE ELSE                                                                       
                     CASE WHEN R2.REGTYPE='R4' THEN R2.REGCODE ELSE                                                                   
                     CASE WHEN R3.REGTYPE='R4' THEN R3.REGCODE ELSE                                                               
                     CASE WHEN R4.REGTYPE='R4' THEN R4.REGCODE ELSE                                                           
                     R5.REGCODE END     
                     END  END                                                                    
                     END 'CENTRECODE',                                                          
                     CASE WHEN R1.REGTYPE='R4' THEN R1.REGNAME                                  
                     ELSE                                                                       
                         CASE WHEN R2.REGTYPE='R4' THEN R2.REGNAME                              
                         ELSE                                                                   
                             CASE WHEN R3.REGTYPE='R4' THEN R3.REGNAME                          
                             ELSE   
                                 CASE WHEN R4.REGTYPE='R4' THEN R4.REGNAME                      
                                 ELSE 
                                     R5.REGNAME                                                 
                                 END 
                             END                                                                
                         END                                                                    
                     END 'CENTRE'                                                               
                     FROM njindiainvest.REGION  R1                                                          
                                              
                                 LEFT  JOIN njindiainvest.REGION  R2 ON R1.REGCODE=R2.REGPARENTCODE AND R2.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R3 ON R2.REGCODE=R3.REGPARENTCODE AND R3.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R4 ON R3.REGCODE=R4.REGPARENTCODE AND R4.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R5 ON R4.REGCODE=R5.REGPARENTCODE AND R5.REGTYPE!='R5'  
                     WHERE  R1.REGCODE  IN (  SELECT REG.REGCODE FROM njindiainvest.REGION REG 
                                              INNER JOIN njindiainvest.ME_REGION MR ON ( MR.REGCODE=REG.REGCODE ) 
                                              INNER JOIN njindiainvest.ME_CHILD MC ON MC.ME_CHILD_CODE=MR.MECODE AND MR.ACTIVATION != 0
                                            )                                    
                     ) z                                                                                
                    where z.CENTRECODE IS NOT NULL                                                     
                    ORDER BY z.CENTRE;


                    DECLARE CUR_CENTER1 CURSOR FOR SELECT CENTRECODE FROM ( SELECT DISTINCT                                                            
                     CASE WHEN R1.REGTYPE='R4' THEN R1.REGCODE ELSE                                                                       
                     CASE WHEN R2.REGTYPE='R4' THEN R2.REGCODE ELSE                                                                   
                     CASE WHEN R3.REGTYPE='R4' THEN R3.REGCODE ELSE                                                               
                     CASE WHEN R4.REGTYPE='R4' THEN R4.REGCODE ELSE                                                           
                     R5.REGCODE END     
                     END  END                                                                    
                     END 'CENTRECODE',                                                          
                     CASE WHEN R1.REGTYPE='R4' THEN R1.REGNAME                                  
                     ELSE                                                                       
                         CASE WHEN R2.REGTYPE='R4' THEN R2.REGNAME                              
                         ELSE                                                                   
                             CASE WHEN R3.REGTYPE='R4' THEN R3.REGNAME                          
                             ELSE   
                                 CASE WHEN R4.REGTYPE='R4' THEN R4.REGNAME                      
                                 ELSE 
                                     R5.REGNAME                                                 
                                 END 
                             END                                                                
                         END                                                                    
                     END 'CENTRE'                                                               
                     FROM njindiainvest.REGION  R1                                                          
                                              
                                 LEFT  JOIN njindiainvest.REGION  R2 ON R1.REGCODE=R2.REGPARENTCODE AND R2.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R3 ON R2.REGCODE=R3.REGPARENTCODE AND R3.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R4 ON R3.REGCODE=R4.REGPARENTCODE AND R4.REGTYPE!='R5'  
                                 LEFT  JOIN njindiainvest.REGION  R5 ON R4.REGCODE=R5.REGPARENTCODE AND R5.REGTYPE!='R5'  
                     WHERE  R1.REGCODE  IN (  SELECT REG.REGCODE FROM njindiainvest.REGION REG 
                                              INNER JOIN njindiainvest.ME_REGION MR ON ( MR.REGCODE=REG.REGCODE ) 
                                              INNER JOIN njindiainvest.ME_CHILD MC ON MC.ME_CHILD_CODE=MR.MECODE AND MR.ACTIVATION != 0
                                              WHERE  MC.ME_PAR_CODE=MECODE
                                            )                                    
                     ) z                                                                                
                    where z.CENTRECODE IS NOT NULL                                                     
                    ORDER BY z.CENTRE;


         DECLARE FINAL_CUR CURSOR FOR SELECT CENTER_CODE FROM CENTER_HIER; 
         DECLARE CONTINUE HANDLER FOR NOT FOUND SET DIST_DONE = 1;
  
         DROP TEMPORARY TABLE IF EXISTS CENTER_HIER;
         CREATE TEMPORARY TABLE CENTER_HIER
         (
            SRNO INT AUTO_INCREMENT PRIMARY KEY,
            CENTER_CODE VARCHAR(20)
               
         ); 

    
   IF EMPTYPE= 'nonsales_emp' AND REPTYPE='region' THEN

        OPEN CUR_CENTER;
        
        FETCH_LOOP: LOOP
        
            FETCH CUR_CENTER INTO V_CENTERCODE;
                IF DIST_DONE THEN
                    LEAVE FETCH_LOOP;
                END IF;

                INSERT INTO CENTER_HIER
                (
                    CENTER_CODE
                )
                VALUES
                (
                   V_CENTERCODE
                );

            END LOOP FETCH_LOOP;
        
        CLOSE CUR_CENTER;

   ELSE
             OPEN CUR_CENTER1;
        
                    FETCH_LOOP: LOOP
        
                        FETCH CUR_CENTER1 INTO V_CENTERCODE;
                        IF DIST_DONE THEN
                        LEAVE FETCH_LOOP;
                        END IF;

                   INSERT INTO CENTER_HIER
                   (
                    CENTER_CODE
                   )
                   VALUES
                   (
                    V_CENTERCODE
                   );

                 END LOOP FETCH_LOOP;
        
             CLOSE CUR_CENTER1;
 END IF;

            SET RES = '';
            SET DIST_DONE = 0;

            OPEN FINAL_CUR;
            L1: LOOP
                FETCH FINAL_CUR INTO F_CENTERCODE;
                IF DIST_DONE THEN
                    LEAVE L1;
                END IF;
                SET RES = CONCAT(RES,'''',F_CENTERCODE,''',');
            END LOOP L1;

            CLOSE FINAL_CUR;

            DROP TEMPORARY TABLE IF EXISTS CENTER_HIER;

            IF(LENGTH(RES) > 0)THEN
                SET RES = SUBSTR(RES,1,LENGTH(RES)-1) ;
            END IF;

            RETURN RES;
END
